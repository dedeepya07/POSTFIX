from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3

app = Flask(__name__)
app.secret_key = "your_secret_key"

# Database setup (SQLite)
def init_sqlite_db():
    conn = sqlite3.connect('users.db')  # Using users.db instead of postal_department.db
    print("Opened database successfully")

    conn.execute('CREATE TABLE IF NOT EXISTS users (username TEXT, password TEXT)')
    print("Table created successfully")
    conn.close()

# Initialize the database
init_sqlite_db()

# Home route with login form
@app.route('/')
def home():
    return render_template('index.html')

# Login processing route
@app.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        with sqlite3.connect('users.db') as conn:  # Use users.db
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password))
            user = cursor.fetchone()

            if user:
                flash("Logged in successfully!", "success")
                return redirect(url_for('home'))
            else:
                flash("Invalid login credentials!", "danger")
                return redirect(url_for('home'))

# Sign up route
@app.route('/signup', methods=['POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        with sqlite3.connect('users.db') as conn:  # Use users.db
            cursor = conn.cursor()
            cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
            conn.commit()
            flash("Account created successfully!", "success")

        return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)